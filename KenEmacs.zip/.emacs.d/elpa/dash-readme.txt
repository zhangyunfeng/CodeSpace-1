A modern list api for Emacs.

See documentation on https://github.com/magnars/dash.el#functions
