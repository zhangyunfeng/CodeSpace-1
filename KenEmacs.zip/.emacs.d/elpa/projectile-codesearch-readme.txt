Description:

This extension makes it convenient to use codesearch with
projectile projects.

For more details, see the project page at
https://github.com/abingham/codesearch.el.

For more details on projectile, see its project page at
http://github.com/bbatsov/projectile

Installation:

The simple way is to use package.el:

    M-x package-install projectile-codesearch

Or, copy projectile-codesearch.el to some location in your emacs
load path. Then add "(require 'projectile-codesearch)" to your
emacs initialization (.emacs, init.el, or something).

Example config:

  (require 'projectile-codesearch)
