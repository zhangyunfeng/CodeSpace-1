Provide smart newline(C-m) which includes open-line(C-o) and newline-and-indent(C-j)
See https://github.com/ainame/smart-newline.el
