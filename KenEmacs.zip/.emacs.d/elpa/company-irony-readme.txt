Usage:

    (eval-after-load 'company
      '(add-to-list 'company-backends 'company-irony))
