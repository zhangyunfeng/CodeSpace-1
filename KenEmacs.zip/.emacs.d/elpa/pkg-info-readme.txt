This library extracts information from installed packages.
