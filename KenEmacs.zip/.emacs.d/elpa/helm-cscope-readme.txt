`helm-cscope.el' is a `helm' interface for xcscope.el.
