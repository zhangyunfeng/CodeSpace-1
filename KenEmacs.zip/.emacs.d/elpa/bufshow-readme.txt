A very simple minor mode for moving forward and backward through an
ordered set of buffers, possibly narrowing the buffer in the
process.

For more information see `bufshow-mode' and `bufshow-start'.
