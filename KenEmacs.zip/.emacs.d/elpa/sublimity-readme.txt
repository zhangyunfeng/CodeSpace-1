Require this script and some of "sublimity-scroll" "sublimity-map".

  (require 'sublimity)
  (require 'sublimity-scroll)

  (require 'sublimity-map)

then call command "M-x sublimity-mode".

If you want to enable sublimity everywhere, call function
sublimity-global-mode.

  (sublimity-global-mode)

For more informations, see "Readme".
